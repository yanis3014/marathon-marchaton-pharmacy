export default function Footer() {
  return (
    <footer className="mt-16 border-t py-10 text-center text-sm text-gray-500">
      50ᵉ anniversaire de la Faculté de Pharmacie de Monastir — 16 novembre 2025
    </footer>
  );
}
